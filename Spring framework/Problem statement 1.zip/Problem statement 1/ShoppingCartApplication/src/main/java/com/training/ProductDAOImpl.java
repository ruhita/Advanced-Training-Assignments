package com.training;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Component;

@Component
public class ProductDAOImpl implements ProductDAO {
	SessionFactory factory = new Configuration().configure("hibernate.cfg.xml")
    		.addAnnotatedClass(Product.class).buildSessionFactory();
	Session theSession = factory.getCurrentSession();
	
	@PersistenceContext
	private EntityManager em;
	
	public void insertProduct(String name,int price,int quantity,String catagory,String brand,String model)
	{
		theSession.beginTransaction();
		Product product= new Product(name, price, quantity, catagory, brand, model);
		theSession.save(product);
		System.out.println("The Product Was added successfully");
		theSession.getTransaction().commit();
		
	}
	
	public void searchById(int id) {
		theSession.beginTransaction();
		Product product = theSession.get(Product.class,id);
		System.out.println(product);
		theSession.getTransaction().commit();
	}
	
	public void deleteById(int id) {
		theSession.beginTransaction();
		Product product = new Product();
		product.setId(id);
		theSession.delete(product);
		System.out.println("The Product was deleted successfully");
		theSession.flush() ;
		theSession.getTransaction().commit();
	}
	
	public void updateById(int id,String name, int price,int quantity,String catagory, String brand, String model ) {
		theSession.beginTransaction();
		String hql="update Product set name=:name,price=:price,quantity=:qua,catagory=:cat,brand=:br,model=:mod where id=:id ";
		Query query=theSession.createQuery(hql);
		query.setParameter("name",name);
		query.setParameter("price",price);
		query.setParameter("qua",quantity);
		query.setParameter("cat",catagory);
		query.setParameter("br",brand);
		query.setParameter("mod",model);
		query.setParameter("id",id);
		query.executeUpdate();
		System.out.println("Updation success");
		theSession.getTransaction().commit();
	}
	
	public void displayAll() {
		theSession.beginTransaction();
		String hql = "FROM Product";
		Query query = theSession.createQuery(hql);
		List<Product> results = query.list();
		System.out.println(results);
	}

	@Override
	public void byCatagory(String catagory) {
		theSession.beginTransaction();
		String hql = "FROM Product where catagory=:cat";
		Query query = theSession.createQuery(hql);
		query.setParameter("cat",catagory);
		List<Product> results = query.list();
		System.out.println(results);
		
	}

	@Override
	public void byBrandOrModel(String brand, String model) {
		theSession.beginTransaction();
		String hql = "FROM Product where brand=:cat or model=:mod";
		Query query = theSession.createQuery(hql);
		query.setParameter("cat",brand);
		query.setParameter("mod",model);
		List<Product> results = query.list();
		System.out.println(results);
		
	}

	@Override
	public void byBrandAndModel(String brand, String model) {
		theSession.beginTransaction();
		String hql = "FROM Product where brand=:cat and model=:mod";
		Query query = theSession.createQuery(hql);
		query.setParameter("cat",brand);
		query.setParameter("mod",model);
		List<Product> results = query.list();
		System.out.println(results);
		
	}

	@Override
	public void byBrandOrModelOrCategory(String brand, String model, String category) {
		theSession.beginTransaction();
		String hql = "FROM Product where brand=:cat or model=:mod or catagory=:br";
		Query query = theSession.createQuery(hql);
		query.setParameter("cat",brand);
		query.setParameter("mod",model);
		query.setParameter("br", category);
		List<Product> results = query.list();
		System.out.println(results);
		
	}
	
	
	
	
	

}
